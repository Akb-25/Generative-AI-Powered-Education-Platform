from django.shortcuts import render, redirect
from .forms import RegisterForm,LoginForm

def login(response):
    if response.method == "POST":
        form = LoginForm(response.POST)
        if form.is_valid():
            form.save()
            return redirect("/home")
    else:
        form = LoginForm()
    return render(response, "login/login.html", {"form": form})
# def register(response):
#     if response.method =="POST":
#         form=RegisterForm(response.POST)
#         if form.is_valid():
#             form.save()
#             return redirect("/home")
#     else:
#         form=RegisterForm()
#     return render(response,"login/register.html",{"form":form})
def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/login")
    else:
        form = RegisterForm()
    return render(request, 'login/register.html', {'form': form})